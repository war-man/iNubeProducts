﻿import React from "react";
import PropTypes from "prop-types";
import withStyles from "@material-ui/core/styles/withStyles";

import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardFooter from "components/Card/CardFooter.jsx";
import loginPageStyle from "assets/jss/material-dashboard-pro-react/views/loginPageStyle.jsx";
import TextField from '@material-ui/core/TextField';
import swal from 'sweetalert';

import { Redirect } from 'react-router-dom'
import { Paper } from "@material-ui/core";

const Styleinput = withStyles({
    root: {
        background: '#e7ab37ad !important',
       // background: '#fff !important',
        borderTopLeftRadius: '5px',
        borderTopRightRadius: '5px'
    },
    //input: {
    //    color:'white'
    //},
    label: {
        //    textTransform: 'capitalize',
        color: '#333'
    },
})(TextField);

class HomePage extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            username: "",
            redirect: false,
            quote: {
                age: "",
                carmake: "",
                pincode: "",
                year: ""
                
            }
        };
    }

    handleinput = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }
    onInputChange = (evt) => {

        const Data = this.state.quote;
        Data[evt.target.name] = evt.target.value;
        this.setState({ Data });
        console.log("Data", this.state.quote)

    }
    renderRedirect = () => {
        if (this.state.redirect === true) {
            return <Redirect to={{
                pathname: '/pages/DriverPage',

            }} />
        }
    }
    quickbuyRedirect = () => {

        this.setState({ redirect: true })
        this.renderRedirect();
    }
    ////handleSubmit = () => {
    ////    fetch(`${ReinsuranceConfig.ReinsuranceConfigUrl}/api/ReInsurance/SaveRetentionData`, {
    ////        method: 'POST',
    ////        headers: {
    ////            'Accept': 'application/json',
    ////            'Content-Type': 'application/json',
    ////            'Authorization': 'Bearer ' + localStorage.getItem('userToken')
    ////        },
    ////        body: JSON.stringify(this.state.Retention)
    ////    }).then(response => response.json())
    ////}

    render() {
        const { classes, loggingIn } = this.props;
        return (
            <div className={classes.container}>
                <h2 className="hero-text">I am a <Styleinput id="text-field-hero" label="Driver Name" variant="filled" value={this.state.quote.age} onChange={this.onInputChange} name='age' formControlProps={{ fullWidth: true }} /> year old, driving a <Styleinput label="Car Make" id="text-field-hero" variant="filled" value={this.state.quote.carmake} onChange={this.onInputChange} name='carmake' formControlProps={{ fullWidth: true }} />.</h2><br />
                <h2 className="hero-text"> My PIN Code is <Styleinput label="Pin Code" id="text-field-hero" variant="filled" value={this.state.quote.pincode} onChange={this.onInputChange} name='pincode' formControlProps={{ fullWidth: true }} /> I have a driving</h2><br />
                <h2 className="hero-text"> experience of <Styleinput label="No. of Year" variant="filled" id="text-field-hero" value={this.state.quote.year} onChange={this.onInputChange} name='year' formControlProps={{ fullWidth: true }} /> Years.</h2><br />
                <GridContainer justify="center">
                    <Button round color="primary" onClick={this.quickbuyRedirect}> Get a quick quote</Button>
                </GridContainer>
                {this.renderRedirect()}
            </div>
            
        );
    }
}

HomePage.propTypes = {
    classes: PropTypes.object.isRequired
};

export default withStyles(loginPageStyle)(HomePage);