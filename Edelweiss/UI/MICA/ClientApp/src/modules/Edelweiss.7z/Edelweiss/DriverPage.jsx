﻿import React from "react";
import PropTypes from "prop-types";
import withStyles from "@material-ui/core/styles/withStyles";

import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import CustomInput from "components/CustomInput/CustomInput.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardFooter from "components/Card/CardFooter.jsx";
import loginPageStyle from "assets/jss/material-dashboard-pro-react/views/loginPageStyle.jsx";
import TextField from '@material-ui/core/TextField';
import swal from 'sweetalert';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Select from '@material-ui/core/Select';
import { Redirect } from 'react-router-dom'
import { Paper, Divider } from "@material-ui/core";
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import MuiButton from '@material-ui/core/Button';
import CustomCheckbox from "components/Checkbox/CustomCheckbox";
import Tooltip from '@material-ui/core/Tooltip';
import GetAppIcon from '@material-ui/icons/GetApp';
import IconButton from '@material-ui/core/IconButton';

const StyleButton = withStyles({
    root: {
        fontSize: '12px',
        //color:'#ddd'
    },
    //label: {
    //    textTransform: 'capitalize',
    //    color: 'white'
    //},
})(MuiButton);

const Styleinput = withStyles({
    root: {
        //background: '#e7ab37ad !important',
        background: '#fff !important',
        borderTopLeftRadius: '5px',
        borderTopRightRadius: '5px'
    },
    //input: {
    //    color:'white'
    //},
    label: {
        //    textTransform: 'capitalize',
        color: 'white'
    },
})(TextField);

class DriverPage extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            username: "15",
            username1:"20",
            value1: 600000,
            value2: 700000,
            value3: 30,
            showdriver1: true,
            showdriver2: false,
            showdriver3: false,
            redirect:false
        };
    }
    renderRedirect = () => {
        if (this.state.redirect === true) {
            return <Redirect to={{
                pathname: '/pages/TPPolicy',

            }} />
        }
    }
    quickbuyRedirect = () => {

        this.setState({ redirect: true })
        this.renderRedirect();
    }
    handleinput = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    handleChange = (event) => {
        console.log(event);
    }

    handleSubmit = () => {
        swal({
            text: "Do Service",
            icon: "error"
        })
    }
    driver1 = () => {
        this.setState({ showdriver1: true, showdriver2: false, showdriver3: false })
    }
    driver2 = () => {
        this.setState({ showdriver2: true, showdriver1: false, showdriver3: false })
    }
    driver3 = () => {
        this.setState({ showdriver3: true, showdriver2: false, showdriver1: false })
    }
    render() {
        const { classes, loggingIn } = this.props;
        return (
            <div className={classes.container}>
                <GridContainer justify="center">
                    <GridItem xs={10}>
                        <Card>                            <CardBody>                                <GridContainer justify="center">                                    <GridItem sm={6}>                                        <Card >                                            <GridContainer justify="center">                                                <Button color="warning" onClick={this.driver1}>Driver 1</Button>
                                                <Button color="warning" onClick={this.driver2}>Driver 2</Button>
                                                <Button color="warning" onClick={this.driver3}>Driver 3</Button>
                                            </GridContainer>
                                        </Card>                                    </GridItem>                                </GridContainer>                                {this.state.showdriver1 ?                                    <div>                                <Card>                                    <GridContainer justify="center">                                        <GridItem>                                            <h2 style={{ marginTop: "0.5rem" }}>Only ₹<b>{this.state.username}</b>/- per day</h2>                                        </GridItem>                                    </GridContainer>                                    <br />                                    <Divider />                                    <GridItem>                                        <h3>Choose sum insured</h3>                                    </GridItem>                                    <GridItem>                                        <GridContainer alignItems="center">                                            <GridItem xs={8} sm={4}>                                                <CustomInput disabled={true} value={this.state.value1} name="value1" />                                            </GridItem>                                            <GridItem xs={8} sm={4}>                                                <CustomInput disabled={true} value={this.state.value1} name="value1" />                                            </GridItem>                                            <GridItem xs={8} sm={4}>                                                <FormControl variant="outlined" className={classes.formControl} formControlProps={{
                                                    fullWidth: true
                                                }} style={{ marginTop: "10px" }}>
                                                    <InputLabel id="demo-simple-select-filled-label" >Sum Insured amount</InputLabel>
                                                    <Select

                                                        InputLabelProps={{}}
                                                        labelId="demo-simple-select-outlined-label"
                                                        id="demo-simple-select-outlined"
                                                        value={this.state.value3}
                                                        onChange={this.handleChange}
                                                        style={{ width: "160px" }}
                                                    //labelWidth={labelWidth}
                                                    >
                                                        <MenuItem value="">
                                                            <em>None</em>
                                                        </MenuItem>
                                                        <MenuItem value={10}>600000</MenuItem>
                                                        <MenuItem value={20}>700000</MenuItem>
                                                        <MenuItem value={30}>800000</MenuItem>
                                                    </Select>
                                                </FormControl>                                            </GridItem>                                        </GridContainer>                                    </GridItem>                                    <GridItem>                                        <GridContainer alignItem="center">                                            <GridItem xs={11}>                                                <StyleButton  > Hard coded marketing message ?</StyleButton>                                            </GridItem>                                            <GridItem xs={1}>                                                <Tooltip title="Click here to download the benefit illustrator" placement="bottom" >                                                    <IconButton justIcon round simple color="default"><GetAppIcon /></IconButton>                                                </Tooltip>                                            </GridItem>                                        </GridContainer>                                    </GridItem>                                </Card>                                <Card>                                    <GridItem>                                        <CustomCheckbox
                                            //name={item.mValue}
                                            labelText="This vehicle is covered under a TP policy"
                                            //value={item.mIsRequired}
                                            //onChange={(e) => props.componentData.SetRiskClaimsDetailsValue('Risk', e)}
                                            //disabled={(item.disable == true) ? true : null}
                                            //checked={item.mIsRequired}
                                            formControlProps={{
                                                fullWidth: true
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem>
                                        <CustomCheckbox
                                            //name={item.mValue}
                                            labelText="Declaration goes here"
                                            //value={item.mIsRequired}
                                            //onChange={(e) => props.componentData.SetRiskClaimsDetailsValue('Risk', e)}
                                            //disabled={(item.disable == true) ? true : null}
                                            //checked={item.mIsRequired}
                                            formControlProps={{
                                                fullWidth: true
                                            }}
                                        />                                    </GridItem>                                </Card>                                <GridContainer justify="center" lg={12}>                                    <GridItem xs={5} sm={3} md={3} lg={2}>                                                <Button color="primary" round onClick={this.quickbuyRedirect}>Quick Buy</Button>                                    </GridItem>                                        </GridContainer>                                     </div> : null}                                 {this.state.showdriver2 ?                                    <div>                                        <Card>                                            <GridContainer justify="center">                                                <GridItem>                                                    <h2 style={{ marginTop: "0.5rem" }}>Only ₹<b>{this.state.username1}</b>/- per day</h2>                                                </GridItem>                                            </GridContainer>                                            <br />                                            <Divider />                                            <GridItem>                                                <h3>Choose sum insured</h3>                                            </GridItem>                                            <GridItem>                                                <GridContainer alignItems="center">                                                    <GridItem xs={8} sm={4}>                                                        <CustomInput disabled={true} value={this.state.value1} name="value1" />                                                    </GridItem>                                                    <GridItem xs={8} sm={4}>                                                        <CustomInput disabled={true} value={this.state.value1} name="value1" />                                                    </GridItem>                                                    <GridItem xs={8} sm={4}>                                                        <FormControl variant="outlined" className={classes.formControl} formControlProps={{
                                                            fullWidth: true
                                                        }} style={{ marginTop: "10px" }}>
                                                            <InputLabel id="demo-simple-select-filled-label" >Sum Insured amount</InputLabel>
                                                            <Select

                                                                InputLabelProps={{}}
                                                                labelId="demo-simple-select-outlined-label"
                                                                id="demo-simple-select-outlined"
                                                                value={this.state.value3}
                                                                onChange={this.handleChange}
                                                                style={{ width: "160px" }}
                                                            //labelWidth={labelWidth}
                                                            >
                                                                <MenuItem value="">
                                                                    <em>None</em>
                                                                </MenuItem>
                                                                <MenuItem value={10}>600000</MenuItem>
                                                                <MenuItem value={20}>700000</MenuItem>
                                                                <MenuItem value={30}>800000</MenuItem>
                                                            </Select>
                                                        </FormControl>                                                    </GridItem>                                                </GridContainer>                                            </GridItem>                                            <GridItem>                                                <GridContainer alignItem="center">                                                    <GridItem xs={11}>                                                        <StyleButton  > Hard coded marketing message ?</StyleButton>                                                    </GridItem>                                                    <GridItem xs={1}>                                                        <Tooltip title="Click here to download the benefit illustrator" placement="bottom" >                                                            <IconButton justIcon round simple color="default"><GetAppIcon /></IconButton>                                                        </Tooltip>                                                    </GridItem>                                                </GridContainer>                                            </GridItem>                                        </Card>                                        <Card>                                            <GridItem>                                                <CustomCheckbox
                                                    //name={item.mValue}
                                                    labelText="This vehicle is covered under a TP policy"
                                                    //value={item.mIsRequired}
                                                    //onChange={(e) => props.componentData.SetRiskClaimsDetailsValue('Risk', e)}
                                                    //disabled={(item.disable == true) ? true : null}
                                                    //checked={item.mIsRequired}
                                                    formControlProps={{
                                                        fullWidth: true
                                                    }}
                                                />
                                            </GridItem>
                                            <GridItem>
                                                <CustomCheckbox
                                                    //name={item.mValue}
                                                    labelText="Declaration goes here"
                                                    //value={item.mIsRequired}
                                                    //onChange={(e) => props.componentData.SetRiskClaimsDetailsValue('Risk', e)}
                                                    //disabled={(item.disable == true) ? true : null}
                                                    //checked={item.mIsRequired}
                                                    formControlProps={{
                                                        fullWidth: true
                                                    }}
                                                />                                            </GridItem>                                        </Card>                                        <GridContainer justify="center" lg={12}>                                            <GridItem xs={5} sm={3} md={3} lg={2}>                                                <Button color="primary" round onClick={this.quickbuyRedirect}>Quick Buy</Button>                                            </GridItem>                                        </GridContainer>                                    </div> : null}                                 {this.state.showdriver3 ?                                    <div>                                        <Card>                                            <GridContainer justify="center">                                                <GridItem>                                                    <h2 style={{ marginTop: "0.5rem" }}>Only ₹<b>{this.state.username}</b>/- per day</h2>                                                </GridItem>                                            </GridContainer>                                            <br />                                            <Divider />                                            <GridItem>                                                <h3>Choose sum insured</h3>                                            </GridItem>                                            <GridItem>                                                <GridContainer alignItems="center">                                                    <GridItem xs={8} sm={4}>                                                        <CustomInput disabled={true} value={this.state.value1} name="value1" />                                                    </GridItem>                                                    <GridItem xs={8} sm={4}>                                                        <CustomInput disabled={true} value={this.state.value1} name="value1" />                                                    </GridItem>                                                    <GridItem xs={8} sm={4}>                                                        <FormControl variant="outlined" className={classes.formControl} formControlProps={{
                                                            fullWidth: true
                                                        }} style={{ marginTop: "10px" }}>
                                                            <InputLabel id="demo-simple-select-filled-label" >Sum Insured amount</InputLabel>
                                                            <Select

                                                                InputLabelProps={{}}
                                                                labelId="demo-simple-select-outlined-label"
                                                                id="demo-simple-select-outlined"
                                                                value={this.state.value3}
                                                                onChange={this.handleChange}
                                                                style={{ width: "160px" }}
                                                            //labelWidth={labelWidth}
                                                            >
                                                                <MenuItem value="">
                                                                    <em>None</em>
                                                                </MenuItem>
                                                                <MenuItem value={10}>600000</MenuItem>
                                                                <MenuItem value={20}>700000</MenuItem>
                                                                <MenuItem value={30}>800000</MenuItem>
                                                            </Select>
                                                        </FormControl>                                                    </GridItem>                                                </GridContainer>                                            </GridItem>                                            <GridItem>                                                <GridContainer alignItem="center">                                                    <GridItem xs={11}>                                                        <StyleButton  > Hard coded marketing message ?</StyleButton>                                                    </GridItem>                                                    <GridItem xs={1}>                                                        <Tooltip title="Click here to download the benefit illustrator" placement="bottom" >                                                            <IconButton justIcon round simple color="default"><GetAppIcon /></IconButton>                                                        </Tooltip>                                                    </GridItem>                                                </GridContainer>                                            </GridItem>                                        </Card>                                        <Card>                                            <GridItem>                                                <CustomCheckbox
                                                    //name={item.mValue}
                                                    labelText="This vehicle is covered under a TP policy"
                                                    //value={item.mIsRequired}
                                                    //onChange={(e) => props.componentData.SetRiskClaimsDetailsValue('Risk', e)}
                                                    //disabled={(item.disable == true) ? true : null}
                                                    //checked={item.mIsRequired}
                                                    formControlProps={{
                                                        fullWidth: true
                                                    }}
                                                />
                                            </GridItem>
                                            <GridItem>
                                                <CustomCheckbox
                                                    //name={item.mValue}
                                                    labelText="Declaration goes here"
                                                    //value={item.mIsRequired}
                                                    //onChange={(e) => props.componentData.SetRiskClaimsDetailsValue('Risk', e)}
                                                    //disabled={(item.disable == true) ? true : null}
                                                    //checked={item.mIsRequired}
                                                    formControlProps={{
                                                        fullWidth: true
                                                    }}
                                                />                                            </GridItem>                                        </Card>                                        <GridContainer justify="center" lg={12}>                                            <GridItem xs={5} sm={3} md={3} lg={2}>                                                <Button color="primary" round onClick={this.quickbuyRedirect}>Quick Buy</Button>                                            </GridItem>                                        </GridContainer>                                    </div> : null}                             </CardBody>                        </Card>                        {this.renderRedirect()}                     </GridItem>                </GridContainer>            </div >

        );
    }
}

DriverPage.propTypes = {
    classes: PropTypes.object.isRequired
};

export default withStyles(loginPageStyle)(DriverPage);